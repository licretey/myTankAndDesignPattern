package com.mashibing.tank;

/**
 * 坦克开火策略
 *
 */
public interface FireStrategy {

	void fire(Tank t);
	
}
