package com.mashibing.tank.abstractfactory;

import java.awt.Graphics;

public abstract class BaseExplode {

	public abstract void paint(Graphics g);
	
}
