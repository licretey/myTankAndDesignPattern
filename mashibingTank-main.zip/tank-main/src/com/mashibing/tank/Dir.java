package com.mashibing.tank;
/**
 * 坦克变动的方向
 * @author Administrator
 */
public enum Dir {
	LEFT,UP,RIGHT,DOWN
}
